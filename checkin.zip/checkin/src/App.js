import logo from './logo.svg';
// import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';  
import Login from './Page/Login/Login';
import Home from './Page/Home/Home'
import CommuteHistory from './Page/CommuteHistory/CommuteHistory.jsx';



function App() {  

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/CommuteHistory' element={<CommuteHistory />}></Route> 
          <Route path='/login' element={<Login />}></Route>
          <Route path='/home' element={<Home />}></Route>
        </Routes>
      </BrowserRouter> 
    </div>
  );
}

export default App;
