import Input from '../../Component/Input/Input.jsx'
import Button from '../../Component/Button/Button.jsx'
import { useState } from 'react';
import styled from 'styled-components';
import axios from 'axios';

const LoginContainer = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  `;

function Login() {
  const [inputs, setInputs] = useState({
    id: "",
    password: "",
  });

  const { id, password } = inputs;

  const handleChange = (e) => {
    const { value, name } = e.target;
    setInputs({
      ...inputs,
      [name]: value,
    });
  };

  const sendData = async () => {


    try {
      const response = await axios.post('/api/v1/userLogin', {"id": id, "pw": password});

          // const response = await axios.post('http://10.0.0.151:4877/api/v1/userLogin', {"id": "bumjin", "pw": "1234"}, {
          //   headers: { "Content-Type": `application/json`}
          //     });

      // 성공적으로 응답을 받았을 때 처리
      if(response.data.id != null) {
      console.log('서버 응답:', response.data);
      window.location.href = "/Home"
      } else if(response.data.id == null) {
        alert("아이디 또는 비밀번호가 잘못 되었습니다.")
      }

    } catch (error) {
      // 오류 발생 시 처리
      console.error('오류 발생:', error);
      console.error('오류 발생:', error);
    }
  };
  return (
    <LoginContainer>
      <div>
        <Input value={id} name="id"
          onChange={handleChange} placeholder={"아이디"} />
        <Input value={password} name="password" type="password"
          onChange={handleChange} placeholder={"비밀번호"} />
        <Button name="button" type="button" onClick={sendData}>로그인</Button>
      </div>
    </LoginContainer>
  );
}

export default Login;
