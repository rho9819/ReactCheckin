import { useEffect, useState } from 'react';
import '../Home/Home.css'
import Logout from '../../Component/Logout/Logout.jsx'
import NickName from '../../Component/NickName/Nickname.jsx'
import DateComponent from '../../Component/Date/Date.jsx'
import CommuteBtn from '../../Component/Button/CommuteBtn/Commutebtn.jsx'
import Calender from '../../Component/Date/Calender/Calender';
import styled from 'styled-components';
import Modal from '../../Component/Modal/modal.jsx';

const Menu = styled.div`
  display: flex;
  height: 80px;
  width: 100vw;
  align-items: center;
  border-bottom: 1px solid #E7E7E7;
`;

const MenuLogout = styled.div`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  margin: 0px 32px 0px 18px;
`

const MenuLeft = styled.div`
  width: 250px;
  height: 92vh;
  border-right: 1px solid #E7E7E7;
  text-align: center;
`

const CalenderPosition = styled.div`
  width: 100vw;
  position: absolute;
  left: 20%;
  top: 10%;
`

const BtnPosition = styled.div`
  width: 150px;
  margin: 0 auto;
`

const Horizontal = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-evenly;
`

const Late = styled.div`
  margin-bottom: 20px;
`

function Home() {
 
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  let [lateText, setLateText] = useState('');
  let [leaveText, setLeaveText] = useState('');
  let [commute, setCommute] = useState(1);
 
  let now = new Date()
  // let today = now.getDate();
  let nowHours = now.getHours();
  let nowMinutes = now.getMinutes();
  let nowDate = now.getDate();
  let nowTime = nowHours * 60 + nowMinutes;

  // 출근 시간
  const startHour = 9;
  const startMinutesOfDay = startHour * 60;
  
  // 퇴근 시간 설정 (다음날 오전 7시)
  const endHour = 6;
  const endMinutesOfDay = endHour * 60; // 다음 날로 설정

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen); // 상태를 현재와 반대로 토글
    // commute: 1 출근 commute: 2 퇴근
    if(commute === 1) {
      setCommute(commute = 2)
    } else if(commute !== 1) {
      setCommute(commute = 1)
    }
  }

  useEffect(() => {
    let commute = 0;
    // 1 출근 2 퇴근
    // 출근이 안 찍혀 있을 떄
    if (commute === 0) {
      if (nowTime > startMinutesOfDay || nowTime < endMinutesOfDay ) {
        // 일정이 생성되지 않은 경우 메시지 표시
        setLateText(nowDate+"일 지각");
        //
      } 
    } else if (commute === 1) {
      // 출근을 찍고 오전 7시 이후가 되었을 때
      if (nowTime > endMinutesOfDay) {
        // 일정이 생성되지 않은 경우 메시지 표시
        setLeaveText(nowDate - 1 +"일 퇴근이 안 찍혀 있습니다.");
      
      } 
    }
}, []);

  return (
    <>
      <Menu>
        <MenuLogout>
          <NickName />
          <Logout />
        </MenuLogout>
      </Menu>

      <MenuLeft>
          <DateComponent />
          {/* commute !== true &&  */}
          {/* todayTime > "0900" && <Late>지각</Late> || todayTime > "2359" && <Late>일정 생성아 안 되어있습니다</Late> */}
          {/* 추가할 것: 출근을 했을 때 or 연차를 썻을 때 */}
          <Late>{lateText}</Late>
          <Late>{leaveText}</Late>
        <BtnPosition>
          <CommuteBtn onClick={toggleModal}>{commute === 1 ? "출근" : "퇴근"}</CommuteBtn>
        </BtnPosition>
        {isModalOpen && <Modal />}
      </MenuLeft>

      <CalenderPosition>
        <Calender />
      </CalenderPosition>
    </>
  );
}

export default Home;
