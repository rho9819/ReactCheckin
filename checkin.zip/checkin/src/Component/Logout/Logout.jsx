function Logout() {
  return (
    <div className="logoutmain">
        <div><a href="login">로그아웃</a></div>
    </div>
  );
}

export default Logout;
