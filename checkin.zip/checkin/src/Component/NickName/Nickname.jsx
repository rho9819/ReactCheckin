import '../NickName/nickname.css';

function NickName() {
  return (
    <div className="nicknamemain">
        <div>노범진</div>
    </div>
  );
}

export default NickName;
