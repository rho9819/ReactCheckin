import React, { Component } from "react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import FullCalendar from '@fullcalendar/react';

export default class Calendar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      events: [
        { title: '출근: 08:00 ~ 퇴근 : 18:00', date: '2023-12-21' },
      ],
    };
  }

  componentDidMount() {
    // 컴포넌트가 처음 마운트될 때 한 번은 수동으로 체크
    this.checkTime();  
}

  componentWillUnmount() {
    // 컴포넌트가 언마운트되면 인터벌 정리
    clearInterval(this.intervalId);
  }
  
  checkTime = () => {
    const now = new Date();
    console.log(now.toISOString().split('T')[0])
    let nowHours = now.getHours();
    let nowMinutes = now.getMinutes();
    let nowTime = nowHours * 60 + nowMinutes;
    
    const startHour = 6;
    const startMinutesOfDay = startHour * 60;
    // if(출근이 null일 떄) {
    if (nowTime > startMinutesOfDay) {
        const newEvent = { title: '출퇴근 기록이 없습니다.', date: "2023-12-12" };
      this.setState(prevState => ({
        events: [...prevState.events, newEvent],
      }));
    }
    // }
  };

  hasEventForToday = () => {
    const today = new Date().toISOString().split('T')[0];
    return this.state.events.some(event => event.date === today);
  };

  
  render() {

    return (
      <>
        <div style={{ display: 'grid', gridTemplateColumns: "2fr 1fr" }}>
          <FullCalendar
            key={this.state.events.length} // FullCalendar를 리렌더링하도록 key 추가
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            initialView={'dayGridMonth'}
            headerToolbar={{
              start: 'today',
              center: 'title',
              end: 'prev,next',
            }}
            height={"85vh"}
            events={this.state.events}
          />
        </div>
      </>
    );
  }
}