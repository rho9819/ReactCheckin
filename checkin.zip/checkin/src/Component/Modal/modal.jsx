import React, { useState } from "react";
import "../Modal/modal.css";
import Map from "../Map/map.jsx";
import Button from "../Button/Button.jsx";
import Home from "../../Page/Home/Home.jsx";

function Modal() {
  const [isModalOpen, setIsModalOpen] = useState(true);
  const [attendanceText, setAttendanceText] = useState(true);

  const isInCircleState = useState(false);
  const [isInCircle, setIsInCircle] = isInCircleState

 
  const closeModal = () => {
    setIsModalOpen(false);
  };

  const toggleText = () => {
    if(!isInCircle) {
      alert("회사 범위 밖에 있습니다.")
      return
    }
    closeModal();
    setAttendanceText(!attendanceText);
  };
  

  return (
    <>
      {isModalOpen && (
        <div className="modal">
          <div className="modal_background">
            <div className="modal_close" onClick={closeModal}>
              X
            </div>
            <Map isInCircleState={isInCircleState} />
            <Button onClick={toggleText} name="button" type="button" >
              {"출근하기"}
            </Button>
          </div>
        </div>
      )}

    </>
  );
}

export default Modal;